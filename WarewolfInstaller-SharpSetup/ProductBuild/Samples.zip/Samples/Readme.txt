Warewolf Sample Projects
-------------------------

1.  Overview
-------------

Warewolf currently ships with samples showing how to execute a workflow from C#, Visual Basic.Net, JavaScript, SQL and VBScript. 
The samples make use of SQL Server databases namely the AdventureWorks database, as well as the WarewolfShoppingCatalog database, 
for which instructions to setup are provided below. There are also samples which show how Warewolf can be used to interface with a third party web service 
(in this case PayPal), the sample uses a dummy account that we have setup for demonstration purposes, 
the account used can easily be changed in the PayPal_RetrieveAuthToken workflow. Code samples can be found in the Install Directory in the Samples folder.
The workflows that are executed in the samples can be found under the Sample Project folder in Warewolf studio.

2. Setup
---------
    a. Database scripts for the Shopping Catalog database are in the Samples folder under the Database Scripts folder. To install the database follow the steps below.

	i.   Open Sql Server Management Studio
	ii.  Open Main.sql
	iii. Execute Main.sql
    
    b. To install the AdventureWorks database please refer to the link below.

http://social.technet.microsoft.com/wiki/contents/articles/3735.sql-server-samples-readme.aspx#Readme_for_Adventure_Works_Sample_Databases

