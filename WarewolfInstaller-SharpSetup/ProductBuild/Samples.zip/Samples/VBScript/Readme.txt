VBScript Sample
-------------
1. Ensure that your Warewolf server is up and running. This can be checked by opening Task Manager, Services tab, Warewolf Server service should have a status of running.

2. Open the Warewolf.vbs file to see how a Warewolf workflow can be executed using VBScript.