//This function demonstrates how to use a standard JasvaScript function to execute a Warewolf workflow.           
		   function loadData (callback){                                           
                  var oReq = new XMLHttpRequest();        
                  oReq.withCredentials  = true; //Required to ensure that Warewolf Server correctly authenticates.
                  oReq.open("GET", "http://localhost:3142/services/Sample Project/GetCategoryTable.json", true);         
                  oReq.onload = function(e) {
                                var data = oReq.responseText // The data received from the workflow execution.
                                callback(data);
                                }
                  oReq.send();   
                 };
