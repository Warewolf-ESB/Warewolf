USE [master]
GO
------------------------------------------------------------------------------------------------
-- WarewolfShoppingCatalog
------------------------------------------------------------------------------------------------
-- Creates the WarewolfShoppingCatalog database.
-- This is the database that is used in the Warewolf Shopping Catalog source under
-- Sources\Sample Project.
------------------------------------------------------------------------------------------------
CREATE DATABASE [WarewolfShoppingCatalog] ON  PRIMARY 
( NAME = N'WarewolfShoppingCatalog', FILENAME = N'D:\MSSQL\Data\WarewolfShoppingCatalog.mdf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'WarewolfShoppingCatalog_log', FILENAME = N'E:\MSSQL\Logs\WarewolfShoppingCatalog_log.ldf' , SIZE = 4096KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET COMPATIBILITY_LEVEL = 100
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [WarewolfShoppingCatalog].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET ARITHABORT OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET AUTO_CREATE_STATISTICS ON 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET  DISABLE_BROKER 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET RECOVERY FULL 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET  MULTI_USER 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET DB_CHAINING OFF 
GO

ALTER DATABASE [WarewolfShoppingCatalog] SET  READ_WRITE 
GO

------------------------------------------------------------------------------------------------
-- Category
------------------------------------------------------------------------------------------------

USE [WarewolfShoppingCatalog]
GO
------------------------------------------------------------------------------------------------
-- Category
------------------------------------------------------------------------------------------------
-- Creates the Category table in the WarewolfShoppingCatalog database.
-- This table stores all the categories used in the Shopping Cart Sample Project.
------------------------------------------------------------------------------------------------
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Category](
	[CategoryID] [int] IDENTITY(1,1) NOT NULL,
	[CategoryName] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_Category] PRIMARY KEY CLUSTERED 
(
	[CategoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

------------------------------------------------------------------------------------------------
-- Products
------------------------------------------------------------------------------------------------
USE [WarewolfShoppingCatalog]
GO
------------------------------------------------------------------------------------------------
-- Products
------------------------------------------------------------------------------------------------
-- Creates the Products table in the WarewolfShoppingCatalog database.
-- This table stores all the products used in the Shopping Cart Sample Project.
------------------------------------------------------------------------------------------------
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Products](
	[ProductID] [int] IDENTITY(1,1) NOT NULL,
	[CategoryID] [int] NOT NULL,
	[CategoryName] [varchar](max) NOT NULL,
	[ProductName] [varchar](max) NOT NULL,
	[Description] [varchar](max) NULL,
	[Price] [money] NOT NULL,
	[Quantity] [int] NOT NULL,
 CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED 
(
	[ProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Products]  WITH CHECK ADD  CONSTRAINT [FK_Products_Category] FOREIGN KEY([CategoryID])
REFERENCES [dbo].[Category] ([CategoryID])
GO

ALTER TABLE [dbo].[Products] CHECK CONSTRAINT [FK_Products_Category]
GO

------------------------------------------------------------------------------------------------
-- spAddCategory
------------------------------------------------------------------------------------------------

USE [WarewolfShoppingCatalog]
GO
------------------------------------------------------------------------------------------------
-- spAddCategory
------------------------------------------------------------------------------------------------
-- This procedure is used to add Categories into the Category table for use in the
-- Shopping Cart. It is used by the Add Category service under the Sample Project category.
------------------------------------------------------------------------------------------------
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spAddCatagory] 
	@Name varchar(MAX) 
AS
BEGIN
	INSERT INTO Category values (@Name)
END
GO

------------------------------------------------------------------------------------------------
-- spAddProduct
------------------------------------------------------------------------------------------------
USE [WarewolfShoppingCatalog]
GO

------------------------------------------------------------------------------------------------
-- spAddProduct
------------------------------------------------------------------------------------------------
-- This procedure is used to add Products into the Product table for use in the
-- Shopping Cart. It is used by the Add Product service under the Sample Project category.
------------------------------------------------------------------------------------------------

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[spAddProduct] 
	@ProductName varchar(MAX),
	@CatagoryID int,
	@Price money,
	@Quantity int,
	@Description varchar(MAX)	
AS
BEGIN
	SET NOCOUNT ON;

	INSERT INTO [Products](ProductName,CategoryID,Price,Quantity,Description) 
		values (@ProductName,@CatagoryID,@Price,@Quantity,@Description)
END
GO



------------------------------------------------------------------------------------------------
-- spEditCategory
------------------------------------------------------------------------------------------------
USE [WarewolfShoppingCatalog]
GO

------------------------------------------------------------------------------------------------
-- spEditCategory
------------------------------------------------------------------------------------------------
-- This procedure is used to edit a Category in the Category table
-- It is used by the Edit Category service under the Sample Project category.
------------------------------------------------------------------------------------------------


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spEditCategory]
	@CategoryIDToUpdate varchar(MAX),
	@NewCategoryName varchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;

    UPDATE dbo.Category SET CategoryName=@NewCategoryName WHERE CategoryID=@CategoryIDToUpdate
END
GO


------------------------------------------------------------------------------------------------
-- spEditProduct
------------------------------------------------------------------------------------------------
USE [WarewolfShoppingCatalog]
GO

------------------------------------------------------------------------------------------------
-- spEditProduct
------------------------------------------------------------------------------------------------
-- This procedure is used to edit a Product in the Product table
-- It is used by the Edit Product service under the Sample Project category.
------------------------------------------------------------------------------------------------

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spEditProduct]
	@ProductNameToUpdate varchar(MAX),
	@NewProductName varchar(MAX),
	@NewCategoryID int,
	@NewDescription varchar(MAX),
	@NewPrice money,
	@NewQuantity int
AS
BEGIN
	SET NOCOUNT ON;

    UPDATE dbo.Products SET ProductName=@NewProductName,CategoryID=@NewCategoryID,Description=@NewDescription,Price=@NewPrice,Quantity=@NewQuantity WHERE ProductName=@ProductNameToUpdate
END
GO

------------------------------------------------------------------------------------------------
-- spDeleteCategory
------------------------------------------------------------------------------------------------
USE [WarewolfShoppingCatalog]
GO
------------------------------------------------------------------------------------------------
-- spDeleteCategory
------------------------------------------------------------------------------------------------
-- This procedure is used to delete a Category from the Category table 
-- It is used by the Delete Category service under the Sample Project category.
------------------------------------------------------------------------------------------------
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spDeleteCategory] 
@CategoryID int
AS
BEGIN
	SET NOCOUNT ON;
	DELETE Category WHERE Category.CategoryID = @CategoryID
END
GO

------------------------------------------------------------------------------------------------
-- spDeleteProduct
------------------------------------------------------------------------------------------------
USE [WarewolfShoppingCatalog]
GO
------------------------------------------------------------------------------------------------
-- spDeleteProduct
------------------------------------------------------------------------------------------------
-- This procedure is used to delete a Product from the Product table.
-- It is used by the Delete Product service under the Sample Project category.
------------------------------------------------------------------------------------------------
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spDeleteProduct]
	@ProductName varchar(MAX)
AS
BEGIN
	SET NOCOUNT ON;

	DELETE Products WHERE ProductName = @ProductName
END
GO

------------------------------------------------------------------------------------------------
-- spGetAllCategories
------------------------------------------------------------------------------------------------
USE [WarewolfShoppingCatalog]
GO

------------------------------------------------------------------------------------------------
-- spGetAllCategories
------------------------------------------------------------------------------------------------
-- This procedure is used to retrieve all Categories from the Category table.
-- It is used by the Get All Categories service under the Sample Project category.
------------------------------------------------------------------------------------------------

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spGetAllCategories]
AS
BEGIN
	SET NOCOUNT ON;

	SELECT * FROM Category
END
GO

------------------------------------------------------------------------------------------------
-- spGetAllProducts
------------------------------------------------------------------------------------------------
USE [WarewolfShoppingCatalog]
GO

------------------------------------------------------------------------------------------------
-- spGetAllProducts
------------------------------------------------------------------------------------------------
-- This procedure is used to retrieve all Products from the Products table
-- It is used by the Get All Products service under the Sample Project category.
------------------------------------------------------------------------------------------------

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[spGetAllProducts]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT prod.ProductID,prod.ProductName,prod.Price,prod.Quantity,prod.Description,cat.CategoryName FROM Products prod INNER JOIN Category cat on prod.CategoryID=cat.CategoryID
END
GO








