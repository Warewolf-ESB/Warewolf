C# Sample
-------------
1. Ensure that your Warewolf server is up and running. This can be checked by opening Task Manager, Services tab, Warewolf Server service should have a status of running.

2. Open the WarewolfCSharp solution.
	- Running the application will execute various calls and show the output from those calls.

Alternatively if Visual Studio is not your IDE, open the Program.cs to see the sample code for calling Workflows from C# code.