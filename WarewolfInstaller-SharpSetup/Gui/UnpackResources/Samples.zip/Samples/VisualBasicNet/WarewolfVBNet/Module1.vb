﻿Imports System.Text
Imports System.IO
Imports System.Net

Module WarewolfVisualBasic

    ''' <summary>
    ''' The services created in Warewolf can easily be called from VB.Net code using a WebRequest.
    ''' By using .json or .xml data can be returned from services in JSON or XML respectively.
    ''' Data can also be passed to a workflow using GET parameters. The workflows executed here
    ''' can all be found under the Sample Project category in Warewolf.
    ''' </summary>
    Sub Main()
        Console.WriteLine("Return Data from Workflow (JSON):")
        Dim categoriesJson As String = CallService("http://localhost:3142/services/GetCategoryTable.json", "GET")
        Console.WriteLine(categoriesJson)

        Console.WriteLine("Return Data from Workflow (XML):")
        Dim categoriesXml As String = CallService("http://localhost:3142/services/GetCategoryTable.xml", "GET")
        Console.WriteLine(categoriesXml)

        Console.WriteLine("Passing Data to Workflow (JSON):")
        Dim url As String = String.Format("{0}?{1}", "http://localhost:3142/services/AddCategory.json", "NewCategoryName=FromConsoleAppJson")
        Dim addStatusJson As String = CallService(url, "GET")
        Console.WriteLine(addStatusJson)

        Console.WriteLine("Passing Data to Workflow (XML):")
        url = String.Format("{0}?{1}", "http://localhost:3142/services/AddCategory.xml", "NewCategoryName=FromConsoleAppXML")
        Dim addStatusXml As String = CallService(url, "GET")
        Console.WriteLine(addStatusXml)

        Console.WriteLine()
        Console.WriteLine("Press any key to continue...")
        Console.ReadKey()
    End Sub

    Private Function CallService(ByVal url As String, ByVal method As String) As String
        Dim req As WebRequest = WebRequest.Create(url)
        req.UseDefaultCredentials = True
        req.Method = method
        Dim resp As HttpWebResponse = CType(req.GetResponse, HttpWebResponse)
        If (Not (resp) Is Nothing) Then
            If (resp.StatusCode = HttpStatusCode.OK) Then
                Dim respStream As Stream = resp.GetResponseStream
                If (Not (respStream) Is Nothing) Then
                    Dim reader As StreamReader = New StreamReader(respStream, Encoding.UTF8)
                    Return reader.ReadToEnd
                End If
            End If
            Console.WriteLine("Status Code: {0}, Status Description: {1}", resp.StatusCode, resp.StatusDescription)
        End If
        Return "FAILED"
    End Function

End Module
