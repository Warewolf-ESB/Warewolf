﻿using System;
using System.IO;
using System.Net;
using System.Text;

namespace WarewolfCSharp
{
    /// <summary>
    /// The services created in Warewolf can easily be called from C# code using a WebRequest.
    /// By using .json or .xml data can be returned from services in JSON or XML respectively.
    /// Data can also be passed to a workflow using GET parameters. The workflows executed here
    /// can all be found under the Sample Project category in Warewolf.
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Return Data from Workflow (JSON):");
            var categoriesJson = CallService(@"http://localhost:3142/services/GetCategoryTable.json", "GET");
            Console.WriteLine(categoriesJson);

            Console.WriteLine("Return Data from Workflow (XML):");
            var categoriesXml = CallService(@"http://localhost:3142/services/GetCategoryTable.xml", "GET");
            Console.WriteLine(categoriesXml);

            Console.WriteLine("Passing Data to Workflow (JSON):");
            var url = string.Format("{0}?{1}", @"http://localhost:3142/services/AddCategory.json", "NewCategoryName=FromConsoleAppJson");
            var addStatusJson = CallService(url, "GET");
            Console.WriteLine(addStatusJson);

            Console.WriteLine("Passing Data to Workflow (XML):");
            url = string.Format("{0}?{1}", @"http://localhost:3142/services/AddCategory.xml", "NewCategoryName=FromConsoleAppXML");
            var addStatusXml = CallService(url, "GET");
            Console.WriteLine(addStatusXml);

            Console.WriteLine();
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        static string CallService(string url, string method)
        {
            WebRequest req = WebRequest.Create(url);
            req.UseDefaultCredentials = true;
            req.Method = method;

            HttpWebResponse resp = req.GetResponse() as HttpWebResponse;

            if(resp != null)
            {
                if(resp.StatusCode == HttpStatusCode.OK)
                {
                    using(Stream respStream = resp.GetResponseStream())
                    {
                        if(respStream != null)
                        {
                            StreamReader reader = new StreamReader(respStream, Encoding.UTF8);
                            return reader.ReadToEnd();
                        }
                    }
                }
                Console.WriteLine("Status Code: {0}, Status Description: {1}", resp.StatusCode, resp.StatusDescription);
            }

            return "FAILED";
        }
    }
}
