Database Scripts for Samples
-----------------------------
1. Ensure that you have Sql Server installed and setup.

2. Open Sql Server Management Studio.

3. Open Main.sql in Sql Server Management Studio.

4. Execute Main.sql script in Sql Server Management Studio.